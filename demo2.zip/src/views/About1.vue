<template>
  <div class="home">
    <img src="../image/img1.png" />
  </div>
</template>

<style lang="scss" scoped>
.home {
  background: white;
}
</style>
