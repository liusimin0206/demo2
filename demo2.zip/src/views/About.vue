<template>
  <div class="about">
    <img height="400px" src="../image/img2.png" />
  </div>
</template>
<style lang="scss" scoped>
.about {
  background: white;
}
</style>
